---
description: List all available checkpoints
---

Use the ClaudePoint MCP tool list_checkpoints to show all available checkpoints.

Display the results in a clear, organized format showing:
- Checkpoint name
- Description
- Date created
- Number of files
- Size
